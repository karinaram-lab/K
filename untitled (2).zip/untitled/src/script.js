document.write('<strong class="bold-text">Добро пожаловать в мою студию монтажа,<br>тут мы вам сделаем монтаж по цене шавухи</strong>');
document.write('<section class="service-block">');
document.write('<h1>Качественный видеомонтаж для YouTube</h1>');
document.write('<p>Создадим динамичное, стильное и вовлекающее видео для вашего YouTube‑канала — от первичной обработки материала до финальной публикации.</p>');
document.write('<h2>Что входит в стоимость:</h2>');
document.write('<ul>');
document.write('<li><strong>1 Логичная структура.</strong> Соберём ролик по сценарию: выделим ключевые моменты, уберём паузы и повторы, добавим плавные переходы.</li>');
document.write('<li><strong>2 Визуальная привлекательность.</strong> Используем анимированные титры, эффекты и фильтры.</li>');
document.write('<li><strong>3 Подберём темп под формат контента:</strong> быстрый для развлекательных роликов.</li>');
document.write('</ul>');
document.write('</section>');
document.write("<section class='service-block' style='text-align: center;'>");
document.body.style.backgroundColor = "black"
document.body.style.backgroundColor = "#4CAF50";
document.body.style.backgroundColor = "rgb(0, 0, 0)";
document.body.style.color = "red"
const priceInfo = `!!!ВАЖНО!!! Цена растёт в зависимости от длительности видеоматериала:
30 минут - 300 рублей
60 минут - 600 рублей
90 минут - 900 рублей`;
document.write(`
  <div style="
    font-weight: bold; 
    white-space: pre-line;
    font-size: 25px; 
  ">
    ${priceInfo}
  </div>
`);